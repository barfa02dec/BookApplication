package com.app.service;

import java.util.List;

import com.app.exception.BookException;
import com.app.model.BookInventory;

public interface BookInventoryInf {
	
	/************* Create ***************/
	public List<BookInventory> addBookInventory(List<BookInventory> book_inventory,int book_id)throws BookException;
	
	
	/************** Read ****************/
	public BookInventory getBookInventoryById(int book_inventory) throws BookException;
	
	
	/**************** Update ******************/
	public BookInventory updateBookInventory(BookInventory book_inventory) throws BookException;
	
}
